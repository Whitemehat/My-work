x = ["Peter" , "ichi" , "somchai"]
z = ""
for i in x:
    y = i + " "
    z += y

print(z)